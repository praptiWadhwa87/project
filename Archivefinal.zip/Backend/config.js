module.exports = {
    email: {
        service: 'gmail',
        auth: {
            user: 'manshusmartboy@gmail.com', 
            pass: 'tpsgqskfqnvctwqb' 
        }
    }
  };
  